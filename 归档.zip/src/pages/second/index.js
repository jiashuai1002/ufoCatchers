import * as React from 'react'
import { ScrollView, Text, View, usePageInstance, usePageEvent } from "remax/wechat";
import CardList from '../../components/cardList'
import './index.less'

export default () => {
    // 获取当前页面的实例
    const pageInstance = usePageInstance();
    console.log(pageInstance)
    // onShow生命周期执行
    usePageEvent('onShow', (item) => {
        console.log('onShow', item)
        // 获取当前页面tabbar实例并初始化
        // pageInstance.getTabBar().init()
    });
    usePageEvent('onLoad', (item) => {
        console.log('onLoad', item)
        // 获取当前页面tabbar实例并初始化
        // pageInstance.getTabBar().init()
    });
    return (
        <ScrollView className="second-page">
            <View className="second-title">{`关于${1},你要知道的事`}</View>
            <CardList />
        </ScrollView>
    )
}
import * as React from "react";
import {
  View,
  ScrollView,
  usePageInstance,
  usePageEvent,
  stopPullDownRefresh,
  request,
  showLoading,
  CoverImage,
  Image,
} from "remax/wechat";
import Gird from '@vant/weapp/dist/grid/index'
import SwiperComponent from "../../components/swiper";
import IconNavComponent from "../../components/iconNav";
import WaterFallListComponent from "../../components/waterFallList";

import testJson from "../../assets/images/images";
import './index.less'

export default () => {
  // 获取当前页面的实例
  const pageInstance = usePageInstance();
  const [text, setText] = React.useState(0);
  console.log("pageInstance", pageInstance.onPullDownRefresh);
  // onShow生命周期执行
  usePageEvent("onShow", () => {
    // 获取当前页面tabbar实例并初始化
    // pageInstance.getTabBar().init()
    // showLoading({
    //   title: "加载数据呢~",
    //   mask: true,
    // });
  });
  usePageEvent("onPullDownRefresh", () => {
    // 获取当前页面tabbar实例并初始化
    // pageInstance.getTabBar().init()
    console.log("refresh");
    setTimeout(stopPullDownRefresh, 1000);
  });
  const swiperData = [testJson.test, testJson.test, testJson.test];
  const loadMore = () => {
    console.log('loadmore')
  }
  return (
    <ScrollView lower-threshold="1" scroll-anchoring="true" bindscrolltolower={loadMore} scroll-y="true" className="index-page">
      {/*  */}
      <SwiperComponent type="small" data={swiperData} />
      <IconNavComponent />
      <WaterFallListComponent />
    </ScrollView>
  );
};

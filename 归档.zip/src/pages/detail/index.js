import * as React from 'react'
import {
  View,
  usePageInstance,
  usePageEvent,
  ScrollView,
  Text,
  Button,
  Image,
  showShareMenu
} from 'remax/wechat'
import Icon from '@vant/weapp/dist/icon/index'
import VanCellGroup from '@vant/weapp/dist/cell-group/index'
import VanField from '@vant/weapp/dist/field/index'
import VanButton from '@vant/weapp/dist/button/index'

import SwiperComponent from '../../components/swiper'
import testJson from '../../assets/images/images'
import './index.less'

export default () => {
  // 获取当前页面的实例
  const pageInstance = usePageInstance()
  // onShow生命周期执行
  usePageEvent('onShow', () => {
    // 获取当前页面tabbar实例并初始化
    // pageInstance.getTabBar().init()
    showShareMenu({
      withShareTicket: true
    })
  })
  const swiperData = [testJson.test, testJson.test, testJson.test]
  const navItemsData = [
    {
      path: '/pages/second/index',
      icon: 'star-o',
      text: '收藏',
      color: '#ec5f59'
    },
    {
      path: '/pages/second/index',
      icon: 'eye-o',
      text: '关注',
      color: '#f0c14a'
    },
    {
      path: '/pages/second/index',
      icon: 'bullhorn-o',
      text: '分享',
      color: '#64bc8e'
    },
    {
      path: '/pages/second/index',
      icon: 'fire-o',
      text: '朋友圈',
      color: '#59a9dd'
    }
  ]
  const tabNavClick = pIndex => {
    switch (pIndex) {
      case 2:
        break
      case 3:
        console.log(1)
        break
      default:
        console.log(1)
        break
    }
  }
  return (
    <ScrollView className='detail-page'>
      <SwiperComponent type='large' data={swiperData} />
      <Text className='title text'>我是一个标题</Text>
      <Text className='text desc'>
        我是一个端介绍我是一个端介绍我是一个端介绍我是一个端介绍我是一个端介绍我是一个端介绍我是一个端介绍我是一个端介绍
      </Text>
      <View className='icon-nav-container'>
        {navItemsData.map((item, index) => (
          <View
            className='icon-nav-item'
            key={index}
            onClick={() => {
              tabNavClick(index)
            }}
          >
            {index === 2 ? (
              <Button class='btn sendFriends shareTips' open-type='share'>
                Share
              </Button>
            ) : null}
            <View className='icon-item-top'>
              <Icon name={item.icon} color='gray' size='38px' />
            </View>
            <Text className='icon-item-bottom'>{item.text}</Text>
          </View>
        ))}
      </View>
      <View className='contact-card'>
        <View className='contact-left'>
          <View>
            <Icon className='icon' name='fire-o' color='gray' size='15px' />
            <Text style='font-size: 25rpx;'>111111111</Text>
          </View>
          <View>
            <Icon className='icon' name='fire-o' color='gray' size='15px' />
            <Text className='icon'>111111111</Text>
            <Text>nickname</Text>
          </View>
        </View>
        <View className='contact-right'>
          <Image className='qr-image' src={testJson.test} />
          <Text className='qr-text'>11111</Text>
        </View>
      </View>
      <View className='user-bar'>
        <Image className='avator' src={testJson.test} />
        <Text className='user-text'>nickname</Text>
        <Text className='user-text'>一个厨师</Text>
        <Text className='user-text'>五天前</Text>
      </View>
      <VanCellGroup>
        <VanField
          value={''}
          center
          clearable
          label='短信验证码'
          placeholder='请输入短信验证码'
          border='false'
          useButtonlot
        >
          <VanButton plain slot='button' size='small' type='primary'>
            发送验证码
          </VanButton>
        </VanField>
      </VanCellGroup>
      <VanButton plain  size='small' type='primary'>
            发送验证码
          </VanButton>
    </ScrollView>
  )
}

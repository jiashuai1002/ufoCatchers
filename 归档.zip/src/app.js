import '@styles/app.css';

const App = props => props.children;

export default App;

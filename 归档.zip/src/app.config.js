module.exports = {
  pages: [
    "pages/index/index",
    "pages/mine/index",
    "pages/publish/index",
    "pages/shop/index",
    "pages/second/index",
    "pages/detail/index"
  ],
  window: {
    navigationBarTitleText: "Remax",
    navigationBarTextStyle: "black",
    navigationBarBackgroundColor: "#ffffff",
    backgroundColor: "#f5f5f5",
    // enablePullDownRefresh: true
  },
  tabBar: {
    color: "#333333",
    selectedColor: "#f26123",
    backgroundColor: "#ffffff",
    borderStyle: "white",
    list: [
      {
        pagePath: "pages/index/index",
        text: "首页",
        iconPath: "./assets/images/icons/gift.png",
        selectedIconPath: "./assets/images/icons/gift_active.png",
      },
      {
        pagePath: "pages/publish/index",
        text: "发布",
        iconPath: "./assets/images/icons/gift.png",
        selectedIconPath: "./assets/images/icons/gift_active.png",
      },
      {
        pagePath: "pages/shop/index",
        text: "商城",
        iconPath: "./assets/images/icons/gift.png",
        selectedIconPath: "./assets/images/icons/gift_active.png",
      },
      {
        pagePath: "pages/mine/index",
        text: "我的",
        iconPath: "./assets/images/icons/gift.png",
        selectedIconPath: "./assets/images/icons/gift_active.png",
      },
    ],
  },
};

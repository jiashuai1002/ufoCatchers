import * as React from 'react'
import {
  ScrollView,
  Image,
  Text,
  View,
  usePageInstance,
  usePageEvent,
  navigateTo
} from 'remax/wechat'
import './index.less'
import testJson from '../../assets/images/images'

export default () => {
  // 获取当前页面的实例
  const pageInstance = usePageInstance()
  console.log(pageInstance)
  // onShow生命周期执行
  usePageEvent('onShow', item => {
    console.log('onShow', item)
    // 获取当前页面tabbar实例并初始化
    // pageInstance.getTabBar().init()
  })
  /**
   * @name {切换关注状态}
   * @param {*} event
   */
  const changeFollow = event => {
    event.stopPropagation()
  }
  return (
    <View className='card-list-container'>
      <View
        className='card-list-item'
        onClick={() => {
          navigateTo({
            // url: `${item.path}?type=${index}&title=${item.text}`
            url: '/pages/detail/index'
          })
        }}
      >
        <Image
          lazy-load='true'
          src={testJson.test}
          className='card-list-item-top'
        />
        <View className='card-list-item-bottom'>
          <View className='card-bottom-top'>
            <Text className='card-list-item-title'>一条大狼狗</Text>
            <Image
              lazy-load='true'
              src={testJson.test}
              className='card-bottom-avator'
            />
            <Text className='card-bottom-nickname'>一条大狼狗</Text>
          </View>
          <View className='card-bottom-bottom'>
            <View className='card-bottom-bottom-left'>
              <Text className='card-bottom-desc'>
                一只很乖很乖的乖宝宝一只很乖很乖的乖宝宝一只很乖很乖的乖宝宝一只很乖很乖的乖宝宝
              </Text>
              <View>
                <Text className='card-bottom-address'>上海市浦东新区</Text>
                <Text className='card-bottom-moment'>三天前</Text>
              </View>
            </View>
            <View className='card-bottom-bottom-right' onClick={changeFollow}>
              关注
            </View>
          </View>
          {/* <Text className="card-list-item-desc">一条大狼狗</Text> */}
        </View>
      </View>
    </View>
  )
}

import * as React from "react";
import { View, navigateTo, Image, Text } from "remax/wechat";
import VanGrid from "@vant/weapp/dist/grid/index";
import VanGridItem from "@vant/weapp/dist/grid-item/index";
import Icon from "@vant/weapp/dist/icon/index";
import "./index.less";

export default () => {
  const navItemsData = [
    {
      path: "/pages/second/index",
      icon: "aim",
      text: "寻猫",
      color: '#ec5f59'
    },
    {
      path: "/pages/second/index",
      icon: "user-o",
      text: "寻主",
      color: '#f0c14a'
    },
    {
      path: "/pages/second/index",
      icon: "smile-o",
      text: "领养",
      color: '#64bc8e'
    },
    {
      path: "/pages/second/index",
      icon: "fire-o",
      text: "求救",
      color: '#59a9dd'
    },
  ];
  return (
    <View className='icon-nav-container'>
      {navItemsData.map((item, index) => (
        <View className="icon-nav-item" key={index} onClick={() => {
          navigateTo({
            url: `${item.path}?type=${index}&title=${item.text}`
          })
        }}>
          <View className="icon-item-top" style={{ background: `${item.color}` }}>
            <Icon name={item.icon} color="white" size="28px" />
          </View>
          <Text className="icon-item-bottom">{item.text}</Text>
        </View>
      ))}
    </View>
  );
};

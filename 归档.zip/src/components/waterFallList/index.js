import * as React from "react";
import { View, Text, Image } from "remax/wechat";
import "./index.less";

import testJson from "../../assets/images/images";


export default ({ data = [] }) => {
  return (
    <View className='waterfall-box'>
      <Text className="waterfall-title">最新动态</Text>
      <View className='waterfall-content'>
        <View className="left-half waterfall-half">
          <View className="waterfall-item">
            <Image lazy-load="true" src={testJson.test} className="waterfall-item-top" />
            <View className="waterfall-item-bottom">
              <Text className="waterfall-item-type">寻狗</Text>
              <Text className="waterfall-item-desc">一条大狼狗</Text>
            </View>
          </View>
        </View>
        <View className="right-half waterfall-half">2222</View>
      </View>
    </View>
  );
};

import * as React from "react";
import { View, Swiper, SwiperItem } from "remax/wechat";
import "./index.less";

export default ({ type = "small", data = [] }) => {
  const swiperItems = data.map((item, index) => (
    <SwiperItem key={index}>
      <View
        className="feat-item"
        style={{ backgroundImage: `url(${item})`, backgroundSize: "cover" }}
      ></View>
    </SwiperItem>
  ));

  return (
    <View>
      <Swiper
        className={`swiper-${type}`}
        // 微信原生组件的Attributes必须换成驼峰才能生效。
        // ex:  indicator-dots × | indicatorDots ✔
        indicatorDots={true}
        indicatorColor="gray"
        indicatorActiveColor="whitesmoke"
        autoplay="true"
        circular="true"
        interval={4396}
      >
        {swiperItems}
      </Swiper>
    </View>
  );
};
